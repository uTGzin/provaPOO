package prova;

public class Disciplina {
	private String nome;
	
	Disciplina(String n) {
		this.nome = n;
	}
	
	public void setNome(String n) {
		this.nome = n;
	}
	
	public String getNome() {
		return this.nome;
	}
}
