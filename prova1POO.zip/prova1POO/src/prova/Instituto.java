package prova;
import java.util.ArrayList;
public class Instituto {
	private String nome;
	private ArrayList <Curso> curso = new ArrayList <Curso>();
	
	Instituto(String n) {
		this.nome = n;
	}
	
	public void setNome (String n) {
		this.nome = n;
	}
	
	public void setCurso (Curso c) {
		curso.add(c);
	}
	
	public String getNome () {
		return this.nome;
	}
	
	public ArrayList<Curso> getCurso () {
		return this.curso;
	}
}
