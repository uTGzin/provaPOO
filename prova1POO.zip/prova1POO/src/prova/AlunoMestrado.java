package prova;

public class AlunoMestrado extends Aluno{
	private String listaPesquisa;
	
	AlunoMestrado (int m, String n,String lPes) {
		super(m, n);
		this.listaPesquisa = lPes;
	}
	
	public void setListaPesquisa(String lPes) {
		this.listaPesquisa = lPes;
	}
	
	public String getListaPesquisa() {
		return this.listaPesquisa;
	}
	
}
