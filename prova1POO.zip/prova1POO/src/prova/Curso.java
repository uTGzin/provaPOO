package prova;

import java.util.ArrayList;

public class Curso {
	private String nome;
	private ArrayList <Disciplina> materia = new ArrayList <Disciplina>();
	private ArrayList <Aluno> turma = new ArrayList <Aluno>();
	
	Curso(String n) {
		this.nome = n;
	}
	
	public void setNome(String n) {
		this.nome = n;
	}
	
	public void setMateria(Disciplina m) {
		materia.add(m);
	}
	
	public void setturma(Aluno t) {
		turma.add(t);
	}
	
	public String getNome() {
		return nome;
	}
	
	public ArrayList<Disciplina> getMateria() {
		return materia;
	}	
}