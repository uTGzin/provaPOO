package prova;

public class Aluno {
	private int matricula;
	private String nome;
	
	Aluno(int m, String n) {
		this.matricula = m;
		this.nome = n;
	}
	
	public void setMatricula (int m) {
		this.matricula = m;
	}
		
	public void setNome (String n) {
		this.nome = n;
	}
	
	public int getMatricula () {
		return this.matricula;
	}
	
	public String getNome() {
		return this.nome;
	}
	
}
