package questao2;

public class Despesa {
	private String descricao;
	private double valor;
	private String dia;
		
	Despesa (String desc, double v,String d) {
		this.descricao = desc;
		this.valor = v;
		this.dia = d;
	}

	public String getDescricao() {
		return this.descricao;
	}

	public double getValor() {
		return this.valor;
	}
	
	public String getDia () {
		return this.dia;
	}
			
	public String toString () {
		return dia + " - " + descricao + " - " + valor;
	}
}
