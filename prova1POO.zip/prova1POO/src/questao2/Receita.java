package questao2;

public class Receita {
	private String descricao;
	private double valor;
	private String dia;
		
	Receita (String descricao, double valor, String dia) {
		this.descricao = descricao;
		this.valor = valor;
		this.dia = dia;
	}

	public String getDescricao() {
		return descricao;
	}

	public double getValor() {
		return valor;
	}
	
	public String getDia () {
		return this.dia;
	}
		
	public String toString () {
		return dia + " - " + descricao + " - " + valor;
	}
}