package questao2;

public class ReceitaIdentificada extends Receita{
	private String cpf;
	
	ReceitaIdentificada(String descricao, double valor, String dia, String cpf) {
		super(descricao, valor, dia);
		this.cpf = cpf;
	}
	
	public String getCpf() {
		return this.cpf;
	}
	
	public String toString () {
		return getDia() + " - " + getDescricao() + "\n" + getCpf() + " - " + getValor();
	}
}
