package questao2;
import java.util.ArrayList;

public class Pessoa {

	private String nome;
	private double valorReservado;
	int mes;
	private ArrayList <Receita> receitas = new ArrayList<Receita>();
	private ArrayList <Despesa> despesas = new ArrayList<Despesa>();
	
	Pessoa (String nome, int mes, double valorReservado) {
		this.nome = nome;
		this.valorReservado = valorReservado;
		this.mes = mes;
	}
		
	void adicionaReceita(String descricao,  double valor, String dia) {
		receitas.add(new Receita(descricao, valor, dia));
	}
	
	void adicionaReceita(String descricao,  double valor, String dia, String cpf) {
		receitas.add(new ReceitaIdentificada(descricao, valor, dia, cpf));
	}
	
	boolean adicionaDespesa(String descricao,  double valor, String dia) {
		if (valorReservado > valor) {
			despesas.add(new Despesa(descricao, valor, dia));
			return true;
		}
		else {
			return false;
		}
	}
	
	double saldoRestante() {
		double total = valorReservado;
		for (Receita i : receitas) {
			total += i.getValor();
		}
		for (Despesa i : despesas) {
			total -= i.getValor();
		}
		return total;
	}
		
	double totalParaGastar() {
		double total = valorReservado;
		for (int i=0;i<receitas.size();i++) {
			total = total + receitas.get(i).getValor();
		}
		return total;
	}

	public String toString() {
		String dadosPessoa = nome + " - Mês : " + mes + "\n" + "Valor Reservado : " + valorReservado + "\n";
		dadosPessoa = dadosPessoa + "Receitas : \n";
		for (int i=0;i<receitas.size();i++) {
			dadosPessoa = dadosPessoa + receitas.get(i) + "\n";
		}
		dadosPessoa = dadosPessoa + "Total Disponível : " + totalParaGastar()  + "\n";
		dadosPessoa = dadosPessoa + "Despesas : \n";		
		for (Despesa j: despesas) {
			dadosPessoa = dadosPessoa + j+ "\n";
		}
		dadosPessoa = dadosPessoa + "Total Disponível : " + saldoRestante()  + "\n";
		
		return  dadosPessoa;
	}	
}
