package questao2;
import javax.swing.JOptionPane;

public class Principal {
	
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null,"Cadastre as Despesas/Receitas de uma pessoa");
		
		String nome = JOptionPane.showInputDialog(null,"Entre com o nome da Pessoa : ");
		int mes = Integer.parseInt(JOptionPane.showInputDialog(null,"Entre com o Mês : "));
		double valorReservado = Double.parseDouble(JOptionPane.showInputDialog(null,"Entre com o valor reservado de " + nome + " para o mês " + mes + " : "));
		
		Pessoa pes = new Pessoa(nome, mes, valorReservado);
		pes.adicionaReceita("doacao", 5000.00, "12", "123456789");
		String resp = JOptionPane.showInputDialog(null,"Entrar com as Despesas/Receitas de " + nome + " ? (S/N)");
		
		while (resp.toUpperCase().equals("S")) {
			String tipo = JOptionPane.showInputDialog(null,"Despesa ou Receita ? (D/R)");
			String descricao = JOptionPane.showInputDialog(null,"Descrição :");
			String dia = JOptionPane.showInputDialog(null,"qual o dia da transacao?:");
			double valor = Double.parseDouble(JOptionPane.showInputDialog(null,"Valor : "));
			
			if (tipo.toUpperCase().equals("R"))
				pes.adicionaReceita(descricao, valor, dia);
			
			else if (tipo.toUpperCase().equals("D"))
				pes.adicionaDespesa(descricao, valor, dia);
				
			resp = JOptionPane.showInputDialog(null,"Adicionar nova Despesa / Receita de " + nome + " ? (S/N)");
			
		}		
		JOptionPane.showMessageDialog(null,pes);
				
	}
}
